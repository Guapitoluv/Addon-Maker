*Problema x Consequência*

- Foco excessivo nas pessoas x Ignora fatores estruturais
- Comportamento complexo x Dificulta previsões
- Conceitos subjetivos x Difíceis de mensurar
- Técnicas motivacionais x Podem ser usadas para manipulação
- Objetivos diferentes x Conflitos entre trabalhador e empresa
- Motivação ≠ produtividade x Não garante melhor desempenho
- Dependência do contexto x Não existe solução universal