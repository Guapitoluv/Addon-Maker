console.log("app.js");

import { AddonMaker } from "../core/addon/addon-maker.js";

export const addon = new AddonMaker("Hidroz");