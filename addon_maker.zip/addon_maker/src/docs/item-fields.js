// src/docs/item-fields.js

export const ITEM_FIELD_INFO = {
    name: {
        title: "Name",
        description:
            "The display name of the item. This is the name shown to the player.",
        example: "Ruby Sword",
        required: true
    },

    identifier: {
        title: "Identifier",
        description:
            "The unique identifier used internally by Minecraft to identify the item. It must contain a namespace.",
        example: "example:ruby_sword",
        required: true
    },

    menuCategory: {
        title: "Creative Category",
        description:
            "Determines the Creative inventory category where the item appears.",
        example: "equipment",
        required: false
    },

    group: {
        title: "Creative Group",
        description:
            "Places the item inside a group within its Creative inventory category.",
        example: "minecraft:itemGroup.name.sword",
        required: false
    },

    hiddenInCommands: {
        title: "Hidden in Commands",
        description:
            "Determines whether the item can be used through commands. When enabled, the item is hidden from command-based item selection.",
        example: "true",
        required: false
    },

    maxStackSize: {
        title: "Maximum Stack Size",
        description:
            "Determines the maximum number of this item that can be placed in one inventory stack.",
        example: "64",
        required: false
    },

    durability: {
        title: "Durability",
        description:
            "Defines the maximum durability of a damageable item.",
        example: "100",
        required: false
    },

    damage: {
        title: "Damage",
        description:
            "Defines the amount of damage dealt by the item when applicable.",
        example: "7",
        required: false
    }
};


export const ITEM_GROUP_INFO = {
    identity: {
        title: "Identity",
        description:
            "Basic information used to identify and describe the item."
    },

    creativeMenu: {
        title: "Creative Menu",
        description:
            "Controls how the item is presented in the Creative inventory, including its category and group."
    },

    components: {
        title: "Components",
        description:
            "Components define the behavior and properties of the item."
    },

    visuals: {
        title: "Visuals",
        description:
            "Controls the visual assets associated with the item, such as icons, textures and models."
    }
};