import { AddonMaker } from "./addon_maker/addon_maker.js";


const addon = new AddonMaker("Ruby Expansion");


const ruby = addon
    .createItem("ruby")
    .setDisplayName("Rubi")
    .setMaxStackSize(64)
    .setIcon("ruby");


ruby.setDurability(100);


console.log(ruby);