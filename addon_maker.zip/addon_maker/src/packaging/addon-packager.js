import JSZip from
    "https://cdn.jsdelivr.net/npm/jszip@3.10.1/+esm";


export class AddonPackager {

    constructor(
        addonName,
        options = {}
    ) {
        if (
            typeof addonName !== "string" ||
            !addonName.trim()
        ) {
            throw new TypeError(
                "Addon name must be a non-empty string."
            );
        }

        this.addonName =
            addonName.trim();

        this.version =
            options.version ?? [1, 0, 0];

        this.minEngineVersion =
            options.minEngineVersion ?? [1, 20, 30];

        this.description =
            options.description ??
            `${this.addonName} Add-On`;
    }


    // =========================
    // PUBLIC API
    // =========================

    async createMcaddon(files) {
        this.validateFiles(files);


        const behaviorPackFiles =
            this.extractPackFiles(
                files,
                "behavior_pack/"
            );


        const resourcePackFiles =
            this.extractPackFiles(
                files,
                "resource_pack/"
            );


        if (
            behaviorPackFiles.size === 0
        ) {
            throw new Error(
                "Behavior Pack is empty."
            );
        }


        if (
            resourcePackFiles.size === 0
        ) {
            throw new Error(
                "Resource Pack is empty."
            );
        }


        /*
         * =========================
         * PACK UUIDs
         * =========================
         */

        const behaviorPackUuid =
            this.generateUUID();

        const resourcePackUuid =
            this.generateUUID();


        /*
         * =========================
         * MANIFESTS
         * =========================
         */

        this.addBehaviorPackManifest(
            behaviorPackFiles,
            behaviorPackUuid,
            resourcePackUuid
        );


        this.addResourcePackManifest(
            resourcePackFiles,
            resourcePackUuid
        );


        /*
         * =========================
         * CREATE MCPACKS
         * =========================
         */

        const behaviorPack =
            await this.createMcpack(
                behaviorPackFiles
            );


        const resourcePack =
            await this.createMcpack(
                resourcePackFiles
            );


        /*
         * =========================
         * CREATE MCADDON
         * =========================
         */

        const addonZip =
            new JSZip();


        addonZip.file(
            `${this.addonName} BP.mcpack`,
            behaviorPack
        );


        addonZip.file(
            `${this.addonName} RP.mcpack`,
            resourcePack
        );


        return addonZip.generateAsync({
            type: "blob",
            compression: "DEFLATE"
        });
    }


    async createMcpack(files) {
        this.validateFiles(files);


        const zip =
            new JSZip();


        for (
            const [filePath, content]
            of files
        ) {
            zip.file(
                filePath,
                content
            );
        }


        return zip.generateAsync({
            type: "blob",
            compression: "DEFLATE"
        });
    }


    // =========================
    // MANIFESTS
    // =========================

    addBehaviorPackManifest(
        files,
        behaviorPackUuid,
        resourcePackUuid
    ) {
        const manifest = {
            format_version: 2,

            header: {
                name:
                    `${this.addonName} BP`,

                description:
                    `${this.description} Behavior Pack`,

                uuid:
                    behaviorPackUuid,

                version:
                    this.version,

                min_engine_version:
                    this.minEngineVersion
            },

            modules: [
                {
                    description:
                        `${this.addonName} Behavior Pack`,

                    type:
                        "data",

                    uuid:
                        this.generateUUID(),

                    version:
                        this.version
                }
            ],

            dependencies: [
                {
                    uuid:
                        resourcePackUuid,

                    version:
                        this.version
                }
            ]
        };


        files.set(
            "manifest.json",

            JSON.stringify(
                manifest,
                null,
                2
            )
        );
    }


    addResourcePackManifest(
        files,
        resourcePackUuid
    ) {
        const manifest = {
            format_version: 2,

            header: {
                name:
                    `${this.addonName} RP`,

                description:
                    `${this.description} Resource Pack`,

                uuid:
                    resourcePackUuid,

                version:
                    this.version,

                min_engine_version:
                    this.minEngineVersion
            },

            modules: [
                {
                    description:
                        `${this.addonName} Resource Pack`,

                    type:
                        "resources",

                    uuid:
                        this.generateUUID(),

                    version:
                        this.version
                }
            ]
        };


        files.set(
            "manifest.json",

            JSON.stringify(
                manifest,
                null,
                2
            )
        );
    }


    // =========================
    // UUID
    // =========================

    generateUUID() {
        if (
            globalThis.crypto &&
            typeof globalThis.crypto.randomUUID ===
                "function"
        ) {
            return globalThis.crypto.randomUUID();
        }


        /*
         * Fallback for environments
         * without crypto.randomUUID().
         */

        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx"
            .replace(
                /[xy]/g,
                character => {
                    const random =
                        Math.random() * 16 | 0;

                    const value =
                        character === "x"
                            ? random
                            : (random & 0x3) | 0x8;

                    return value.toString(16);
                }
            );
    }


    // =========================
    // FILE EXTRACTION
    // =========================

    extractPackFiles(
        files,
        prefix
    ) {
        const packFiles =
            new Map();


        for (
            const [filePath, content]
            of files
        ) {
            if (
                !filePath.startsWith(prefix)
            ) {
                continue;
            }


            const relativePath =
                filePath.slice(
                    prefix.length
                );


            if (!relativePath) {
                continue;
            }


            packFiles.set(
                relativePath,
                content
            );
        }


        return packFiles;
    }


    // =========================
    // VALIDATION
    // =========================

    validateFiles(files) {
        if (!(files instanceof Map)) {
            throw new TypeError(
                "Files must be a Map."
            );
        }


        for (
            const [filePath]
            of files
        ) {
            if (
                typeof filePath !== "string" ||
                !filePath.trim()
            ) {
                throw new TypeError(
                    "Every file path must be a non-empty string."
                );
            }
        }
    }


    // =========================
    // DOWNLOAD
    // =========================

    download(
        blob,
        fileName
    ) {
        if (!(blob instanceof Blob)) {
            throw new TypeError(
                "Expected a Blob."
            );
        }


        if (
            typeof fileName !== "string" ||
            !fileName.trim()
        ) {
            throw new TypeError(
                "File name must be a non-empty string."
            );
        }


        const url =
            URL.createObjectURL(blob);


        const anchor =
            document.createElement("a");


        anchor.href =
            url;

        anchor.download =
            fileName;


        document.body.appendChild(
            anchor
        );


        anchor.click();


        anchor.remove();


        setTimeout(
            () => {
                URL.revokeObjectURL(
                    url
                );
            },
            1000
        );
    }


    async createAndDownloadMcaddon(
        files
    ) {
        const blob =
            await this.createMcaddon(
                files
            );


        const fileName =
            `${this.addonName}.mcaddon`;


        this.download(
            blob,
            fileName
        );
    }
}