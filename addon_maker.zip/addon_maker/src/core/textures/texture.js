class Texture extends Image {
    constructor(file) {
        super(file);

        this.validate(file);
    }

    validate(file) {
        if (!(file instanceof File)) {
            throw new TypeError(
                "Texture must be created from a File."
            );
        }

        if (file.type !== "image/png") {
            throw new TypeError(
                "Texture must be a PNG image."
            );
        }
    }
}