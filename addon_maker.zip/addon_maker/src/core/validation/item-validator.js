// src/core/validation/item-validator.js

export class ItemValidator {

    validate(item) {
        const result = {
            valid: true,
            fields: {}
        };

        this.validateIdentifier(item, result);
        this.validateDisplayName(item, result);
        this.validateMenuCategory(item, result);
        this.validateGroup(item, result);
        this.validateComponents(item, result);

        result.valid =
            !Object.values(result.fields)
                .some(field => field.status === "error");

        return result;
    }


    validateIdentifier(item, result) {
        const identifier = item.identifier;

        if (typeof identifier !== "string") {
            this.error(
                result,
                "identifier",
                "Identifier must be a string."
            );

            return;
        }

        if (!identifier) {
            this.error(
                result,
                "identifier",
                "Identifier is required."
            );

            return;
        }

        const pattern =
            /^[a-z0-9_]+:[a-z0-9_]+$/;

        if (!pattern.test(identifier)) {
            this.error(
                result,
                "identifier",
                "Identifier must use the form namespace:name."
            );

            return;
        }

        const [namespace] =
            identifier.split(":");

        if (namespace === "minecraft") {
            this.error(
                result,
                "identifier",
                'The "minecraft" namespace is reserved for vanilla Minecraft items.'
            );

            return;
        }

        this.success(
            result,
            "identifier"
        );
    }


    validateDisplayName(item, result) {
        if (
            typeof item.displayName !== "string" ||
            !item.displayName.trim()
        ) {
            this.error(
                result,
                "name",
                "Display name is required."
            );

            return;
        }

        this.success(result, "name");
    }


    validateMenuCategory(item, result) {
        if (item.menuCategory === null) {
            this.optional(
                result,
                "menuCategory"
            );

            return;
        }

        const categories = [
            "construction",
            "nature",
            "equipment",
            "items",
            "none"
        ];

        if (!categories.includes(item.menuCategory)) {
            this.error(
                result,
                "menuCategory",
                `Invalid category "${item.menuCategory}".`
            );

            return;
        }

        this.success(
            result,
            "menuCategory"
        );
    }


    validateGroup(item, result) {
        if (item.group === null) {
            this.optional(
                result,
                "group"
            );

            return;
        }

        if (
            typeof item.group !== "string" ||
            !item.group.trim()
        ) {
            this.error(
                result,
                "group",
                "Group cannot be empty."
            );

            return;
        }

        if (item.group.length > 256) {
            this.error(
                result,
                "group",
                "Group cannot contain more than 256 characters."
            );

            return;
        }

        if (!item.group.includes(":")) {
            this.error(
                result,
                "group",
                "Group should contain a namespace."
            );

            return;
        }

        this.success(
            result,
            "group"
        );
    }


    validateComponents(item, result) {
        if (!item.components) {
            this.success(
                result,
                "components"
            );

            return;
        }

        if (
            typeof item.components !== "object" ||
            Array.isArray(item.components)
        ) {
            this.error(
                result,
                "components",
                "Components must be an object."
            );

            return;
        }

        this.success(
            result,
            "components"
        );
    }


    success(result, field) {
        result.fields[field] = {
            status: "success",
            message: null
        };
    }


    optional(result, field) {
        result.fields[field] = {
            status: "optional",
            message: null
        };
    }


    error(result, field, message) {
        result.fields[field] = {
            status: "error",
            message
        };
    }
}