import { Addon } from "./addon.js";


export class AddonMaker {
    constructor(name, namespace = null) {
        this.addon =
            new Addon(
                name,
                namespace
            );
    }


    // =========================
    // ADDON
    // =========================

    getAddon() {
        return this.addon;
    }


    // =========================
    // ITEMS
    // =========================

    createItem(
        name,
        identifier = null
    ) {
        return this.addon.createItem(
            name,
            identifier
        );
    }


    getItem(identifier) {
        if (typeof identifier !== "string")
            throw new TypeError(
                "Item identifier must be a string."
            );

        return this.addon.getItem(
            identifier
        );
    }


    hasItem(identifier) {
        if (typeof identifier !== "string")
            throw new TypeError(
                "Item identifier must be a string."
            );

        return this.addon.hasItem(
            identifier
        );
    }


    removeItem(identifier) {
        if (typeof identifier !== "string")
            throw new TypeError(
                "Item identifier must be a string."
            );

        return this.addon.removeItem(
            identifier
        );
    }


    getItems() {
        return this.addon.getItems();
    }


    clearItems() {
        this.addon.clearItems();

        return this;
    }


    // =========================
    // IDENTIFIERS
    // =========================

    createIdentifier(name) {
        if (typeof name !== "string")
            throw new TypeError(
                "Item name must be a string."
            );

        const normalizedName =
            name.trim();

        if (!normalizedName)
            throw new Error(
                "Item name cannot be empty."
            );

        const itemName =
            normalizedName
                .toLowerCase()
                .replace(
                    /[^a-z0-9_]/g,
                    "_"
                );

        return `${this.addon.namespace}:${itemName}`;
    }
}