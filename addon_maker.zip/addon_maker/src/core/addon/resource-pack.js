export class ResourcePack {
    constructor(addon) {
        this.addon = addon;

        this.itemTextures = new Map();
        this.textures = new Map();
        this.models = new Map();
        this.animations = new Map();
        this.animationControllers = new Map();
        this.renderControllers = new Map();
        this.sounds = new Map();
        this.attachables = new Map();
    }

    // =========================
    // ITEM TEXTURES
    // =========================

    addItemTexture(name, texture) {
        this.itemTextures.set(name, texture);

        return texture;
    }

    getItemTexture(name) {
        return this.itemTextures.get(name);
    }

    hasItemTexture(name) {
        return this.itemTextures.has(name);
    }

    removeItemTexture(name) {
        return this.itemTextures.delete(name);
    }

    // =========================
    // TEXTURES
    // =========================

    addTexture(name, texture) {
        this.textures.set(name, texture);

        return texture;
    }

    getTexture(name) {
        return this.textures.get(name);
    }

    hasTexture(name) {
        return this.textures.has(name);
    }

    removeTexture(name) {
        return this.textures.delete(name);
    }

    // =========================
    // MODELS
    // =========================

    addModel(name, model) {
        this.models.set(name, model);

        return model;
    }

    getModel(name) {
        return this.models.get(name);
    }

    hasModel(name) {
        return this.models.has(name);
    }

    removeModel(name) {
        return this.models.delete(name);
    }

    // =========================
    // ATTACHABLES
    // =========================

    addAttachable(name, attachable) {
        this.attachables.set(name, attachable);

        return attachable;
    }

    getAttachable(name) {
        return this.attachables.get(name);
    }

    hasAttachable(name) {
        return this.attachables.has(name);
    }

    removeAttachable(name) {
        return this.attachables.delete(name);
    }
}