console.log("addon.js");

import { BehaviorPack } from "./behavior-pack.js";
import { ResourcePack } from "./resource-pack.js";
import { Item } from "../item/item.js";


export class Addon {
    constructor(name, namespace = null) {
        this.name = this.validateName(name);
        
        this.namespace =
            namespace === null
                ? this.createNamespace(name)
                : this.validateNamespace(namespace);
        
        this.icon = null;
        this.items = new Map();
    }

    // =========================
    // ADDON
    // =========================

    validateName(name) {
        if (typeof name !== "string" || !name.trim()) {
            throw new TypeError(
                "Addon name must be a non-empty string."
            );
        }

        return name.trim();
    }

    createNamespace(name) {
        const namespace = name
            .toLowerCase()
            .trim()
            .replace(/[^a-z0-9_]/g, "_");

        if (!namespace) {
            throw new Error(
                "Could not create a valid namespace."
            );
        }

        return namespace;
    }

    validateNamespace(namespace) {
        if (typeof namespace !== "string") {
            throw new TypeError(
                "Namespace must be a string."
            );
        }

        const pattern = /^[a-z0-9_]+$/;

        if (!pattern.test(namespace)) {
            throw new Error(
                `Invalid namespace: "${namespace}".`
            );
        }

        return namespace;
    }

    // =========================
    // ITEMS
    // =========================

    createItem(name, identifier = null) {
        if (
            typeof name !== "string" ||
            !name.trim()
        ) {
            throw new TypeError(
                "Item name must be a non-empty string."
            );
        }

        if (identifier === null) {
            identifier = this.createIdentifier(name);
        } else {
            this.validateItemIdentifier(identifier);
        }

        if (this.items.has(identifier)) {
            throw new Error(
                `Item "${identifier}" already exists.`
            );
        }

        const item = new Item(identifier);

        item.setDisplayName(name);

        this.items.set(identifier, item);

        return item;
    }

    createIdentifier(name) {
        if (
            typeof name !== "string" ||
            !name.trim()
        ) {
            throw new TypeError(
                "Item name must be a non-empty string."
            );
        }

        const itemName = name
            .toLowerCase()
            .trim()
            .replace(/[^a-z0-9_]/g, "_");

        if (!itemName) {
            throw new Error(
                "Could not create a valid item identifier."
            );
        }

        return `${this.namespace}:${itemName}`;
    }

    validateItemIdentifier(identifier) {
        if (typeof identifier !== "string") {
            throw new TypeError(
                "Item identifier must be a string."
            );
        }

        const pattern = /^[a-z0-9_]+:[a-z0-9_]+$/;

        if (!pattern.test(identifier)) {
            throw new Error(
                `Invalid item identifier: "${identifier}".`
            );
        }
    }
    
    // =========================
    // ICON
    // =========================
    
    setIcon(file) {
        if (!(file instanceof File)) {
            throw new TypeError("Addon icon must be a File.");
        }
    
        if (file.type !== "image/png") {
            throw new TypeError("Addon icon must be a PNG image.");
        }
    
        this.icon = file;
    
        return this;
    }
    
    removeIcon() {
        this.icon = null;
        return this;
    }
    
    hasIcon() {
        return this.icon !== null;
    }
    
    getIcon() {
        return this.icon;
    }

    // =========================
    // LOOKUP
    // =========================

    getItem(identifier) {
        return this.items.get(identifier);
    }

    hasItem(identifier) {
        return this.items.has(identifier);
    }

    removeItem(identifier) {
        return this.items.delete(identifier);
    }

    getItems() {
        return [...this.items.values()];
    }

    clearItems() {
        this.items.clear();

        return this;
    }
}