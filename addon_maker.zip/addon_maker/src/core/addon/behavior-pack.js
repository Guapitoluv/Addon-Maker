export class BehaviorPack {
    constructor(addon) {
        this.addon = addon;

        this.items = new Map();
        this.blocks = new Map();
        this.entities = new Map();
        this.functions = new Map();
        this.scripts = new Map();
    }

    // =========================
    // ITEMS
    // =========================

    addItem(item) {
        if (this.items.has(item.identifier))
            throw new Error(
                `Behavior Pack already contains "${item.identifier}".`
            );

        this.items.set(item.identifier, item);

        return item;
    }

    getItem(identifier) {
        return this.items.get(identifier);
    }

    hasItem(identifier) {
        return this.items.has(identifier);
    }

    removeItem(identifier) {
        return this.items.delete(identifier);
    }

    // =========================
    // UTILIDADES
    // =========================

    getItems() {
        return [...this.items.values()];
    }

    clearItems() {
        this.items.clear();

        return this;
    }
}