import { Recipe } from "./recipe.js";

export class ShapedRecipe extends Recipe {
    constructor(identifier) {
        super(identifier);

        this.pattern = [];
        this.key = {};
        this.result = null;
        this.priority = 0;
        this.assumeSymmetry = false;
    }
}