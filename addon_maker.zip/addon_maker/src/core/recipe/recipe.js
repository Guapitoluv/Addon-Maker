export class Recipe {
    constructor(identifier) {
        this.identifier = identifier;
        this.tags = [];
    }
}