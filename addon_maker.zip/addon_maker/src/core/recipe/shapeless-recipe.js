import { Recipe } from "./recipe.js";

export class ShapelessRecipe extends Recipe {
    constructor(identifier) {
        super(identifier);

        this.ingredients = [];
        this.result = null;
        this.priority = 0;
    }
}