export class Icon {
    constructor(file) {
        this.file = file;
        
        this.name = null;
        this.path = null;
    }
    
    validateName(name) {
        if (!name) return;
        if ()
    }
}


export class Texture {
    constructor(file) {
        this.file = file;

        this.name = null;
        this.width = null;
        this.height = null;
        this.path = null;
    }
    
    loadMetaData() {
        this.name = 
    }
}

class Model {
    constructor(file) {
        this.file = file;
        this.formatVersion = null;
        this.geometries = [];
    }
}

class Geometry {
    constructor(identifier) {
        this.identifier = identifier;

        this.textureWidth = null;
        this.textureHeight = null;

        this.visibleBounds = null;

        this.bones = [];
    }
}

class Bone {
    constructor(name) {
        this.name = name;

        this.parent = null;

        this.pivot = [0, 0, 0];
        this.rotation = [0, 0, 0];

        this.binding = null;

        this.cubes = [];
    }
}