export class Item {
    constructor(identifier) {
        this.validateIdentifier(identifier);

        this.identifier = identifier;

        this.displayName = null;

        this.menuCategory = null;
        this.group = null;
        this.hiddenInCommands = false;

        this.components = {};

        this.assets = {
            icon: null,
            texture: null,
            model: {
                geometry: null,
                geometryIdentifier: null
            }
        };
    }

    // =========================
    // IDENTITY
    // =========================

    validateIdentifier(identifier) {
        if (typeof identifier !== "string") {
            throw new TypeError(
                "Item identifier must be a string."
            );
        }

        const pattern = /^[a-z0-9_]+:[a-z0-9_]+$/;

        if (!pattern.test(identifier)) {
            throw new Error(
                `Invalid item identifier: "${identifier}".`
            );
        }
    }

    // =========================
    // DISPLAY
    // =========================

    setDisplayName(name) {
        if (typeof name !== "string" || !name.trim()) {
            throw new TypeError(
                "Display name must be a non-empty string."
            );
        }

        this.displayName = name;

        return this;
    }

    removeDisplayName() {
        this.displayName = null;

        return this;
    }

    // =========================
    // CREATIVE MENU
    // =========================

    setMenuCategory(category) {
        if (typeof category !== "string") {
            throw new TypeError(
                "Menu category must be a string."
            );
        }

        this.menuCategory = category;

        return this;
    }

    removeMenuCategory() {
        this.menuCategory = null;

        return this;
    }

    setGroup(group) {
        if (typeof group !== "string") {
            throw new TypeError(
                "Group must be a string."
            );
        }

        this.group = group;

        return this;
    }

    removeGroup() {
        this.group = null;

        return this;
    }

    setHiddenInCommands(hidden = true) {
        this.hiddenInCommands = Boolean(hidden);

        return this;
    }

    // =========================
    // COMPONENTS
    // =========================

    setComponent(name, value) {
        if (typeof name !== "string" || !name) {
            throw new TypeError(
                "Component name must be a non-empty string."
            );
        }

        this.components[name] = value;

        return this;
    }

    getComponent(name) {
        return this.components[name];
    }

    hasComponent(name) {
        return Object.hasOwn(this.components, name);
    }

    removeComponent(name) {
        delete this.components[name];

        return this;
    }

    clearComponents() {
        this.components = {};

        return this;
    }

    // =========================
    // COMMON COMPONENTS
    // =========================

    setMaxStackSize(size) {
        if (!Number.isInteger(size) || size <= 0) {
            throw new TypeError(
                "Max stack size must be a positive integer."
            );
        }

        return this.setComponent(
            "minecraft:max_stack_size",
            size
        );
    }

    removeMaxStackSize() {
        return this.removeComponent(
            "minecraft:max_stack_size"
        );
    }

    setDurability(maxDurability) {
        if (
            !Number.isInteger(maxDurability) ||
            maxDurability <= 0
        ) {
            throw new TypeError(
                "Max durability must be a positive integer."
            );
        }

        return this.setComponent(
            "minecraft:durability",
            {
                max_durability: maxDurability
            }
        );
    }

    removeDurability() {
        return this.removeComponent(
            "minecraft:durability"
        );
    }

    setDamage(damage) {
        if (typeof damage !== "number") {
            throw new TypeError(
                "Damage must be a number."
            );
        }

        return this.setComponent(
            "minecraft:damage",
            damage
        );
    }

    removeDamage() {
        return this.removeComponent(
            "minecraft:damage"
        );
    }

    // =========================
    // ASSETS
    // =========================
    
    setIcon(file) {
        if (!(file instanceof File)) {
            throw new TypeError(
                "Icon must be a File."
            );
        }
    
        if (file.type !== "image/png") {
            throw new TypeError(
                "Icon must be a PNG image."
            );
        }
    
        this.assets.icon = file;
    
        return this;
    }
    
    removeIcon() {
        this.assets.icon = null;
    
        return this;
    }
    
    hasIcon() {
        return this.assets.icon !== null;
    }
    
    getIcon() {
        return this.assets.icon;
    }


    setTexture(file) {
        if (!(file instanceof File)) {
            throw new TypeError(
                "Texture must be a File."
            );
        }
    
        if (file.type !== "image/png") {
            throw new TypeError(
                "Texture must be a PNG image."
            );
        }
    
        this.assets.texture = file;
    
        return this;
    }
    
    removeTexture() {
        this.assets.texture = null;
    
        return this;
    }
    
    hasTexture() {
        return this.assets.texture !== null;
    }
    
    getTexture() {
        return this.assets.texture;
    }


    setModel(file, geometryIdentifier) {
        if (!(file instanceof File)) {
            throw new TypeError(
                "Model must be a File."
            );
        }
    
        if (file.type !== "application/json") {
            throw new TypeError(
                "Model must be a JSON file."
            );
        }
    
        if (
            typeof geometryIdentifier !== "string" ||
            !geometryIdentifier.trim()
        ) {
            throw new TypeError(
                "Geometry identifier must be a non-empty string."
            );
        }
    
        this.assets.model.geometry = file;
        this.assets.model.geometryIdentifier =
            geometryIdentifier.trim();
    
        return this;
    }
    
    removeModel() {
        this.assets.model.geometry = null;
        this.assets.model.geometryIdentifier = null;
    
        return this;
    }
    
    hasModel() {
        return this.assets.model.geometry !== null;
    }
    
    getModel() {
        return this.assets.model;
    }
}