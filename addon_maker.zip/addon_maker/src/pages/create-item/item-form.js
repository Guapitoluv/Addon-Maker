export class ItemForm {
    constructor(
        elements,
        addon,
        validator,
        validationUI
    ) {
        this.elements = elements;
        this.addon = addon;
        this.validator = validator;
        this.validationUI = validationUI;
    }

    getInputValue(tag) {
        return this.elements
            .get(tag)
            .value
            .trim();
    }

    getProperties() {
        return {
            name:
                this.getInputValue(
                    "itemNameInput"
                ),

            identifier:
                this.getInputValue(
                    "itemIdentifierInput"
                ),

            menuCategory:
                this.getInputValue(
                    "itemMenuCategoryInput"
                ),

            group:
                this.getInputValue(
                    "itemGroupInput"
                )
        };
    }

    async create() {
        const properties =
            this.getProperties();
        
        const icon =
            this.elements
                .get("itemIconInput")
                .files[0] ?? null;
        
        const texture =
            this.elements
                .get("itemTextureInput")
                .files[0] ?? null;
        
        const model =
            this.elements
                .get("itemModelInput")
                .files[0] ?? null;
        
        let modelIdentifier = null;
        
        if (model !== null) {
            const modelText =
                await model.text();
        
            const modelData =
                JSON.parse(modelText);
        
            modelIdentifier =
                modelData
                    ["minecraft:geometry"][0]
                    ["description"]
                    ["identifier"];
        }
        
        if (!properties.name) {
            throw new Error(
                "Name field can't be empty."
            );
        }
        
        const item =
            this.addon.createItem(
                properties.name,
                properties.identifier || null
            );
        
        if (icon !== null) {
            item.setIcon(icon);
        }
        
        if (texture !== null) {
            item.setTexture(texture);
        }
        
        if (model !== null) {
            item.setModel(model, modelIdentifier);
        }
        
        if (properties.menuCategory) {
            item.setMenuCategory(
                properties.menuCategory
            );
        }

        if (properties.group) {
            item.setGroup(
                properties.group
            );
        }

        const validation =
            this.validator.validate(item);

        this.validationUI.update(
            validation
        );

        if (!validation.valid) {
            throw new Error(
                "Item contains validation errors."
            );
        }

        return item;
    }
}