import { addon } from "../../app/app.js";

import { ItemExporter } from "../../exporters/item-exporter.js";
import { AddonExporter } from "../../exporters/addon-exporter.js";

import { AddonPackager } from "../../packaging/addon-packager.js";

import { InfoPopover } from "../../ui/info/info-popover.js";
import { ItemValidator } from "../../core/validation/item-validator.js";
import { ValidationUI } from "../../ui/validation/validation-ui.js";

import { DOMElements } from "./elements.js";

import { ItemForm } from "./item-form.js";
import { ItemList } from "./item-list.js";
import { ItemPreview } from "./item-preview.js";
import { ItemDownload } from "./item-export.js";
import { ItemEvents } from "./item-events.js";

function debug(message) {
    const output = document.getElementById("debug-output");

    if (!output) return;

    output.textContent += `${message}\n`;
}

debug("start create-item.js");

const elements = new DOMElements({
    itemIdentifierInput: "item-identifier-input",
    itemNameInput: "item-name-input",
    itemCreationConfirmBtn: "item-creation-confirm-btn",
    successSpan: "item-creation-success-span",
    itemList: "item-list",
    output: "output",
    itemMenuCategoryInput: "item-menu-category-input",
    itemGroupInput: "item-group-input",
    itemIconInput: "item-icon-input",
    itemTextureInput: "item-texture-input",
    itemModelInput: "item-model-input"
});

elements.group("itemInputs", [
    "itemIdentifierInput",
    "itemNameInput",
    "itemMenuCategoryInput",
    "itemGroupInput",
    "itemIconInput",
    "itemTextureInput",
    "itemModelInput"
]);

elements.cloneGroup(
    "clearOnCreation",
    "itemInputs"
);


const infoPopover = new InfoPopover();
const validator = new ItemValidator();
const validationUI = new ValidationUI();

const itemForm = new ItemForm(
    elements,
    addon,
    validator,
    validationUI
);

const itemPreview = new ItemPreview(
    elements,
    ItemExporter
);

const itemList = new ItemList(
    elements,
    item => itemPreview.show(item)
);

const itemDownload = new ItemDownload(ItemExporter);


class CreateItemController {
    
    showInfo(field, group) {
        infoPopover.show(field, group);
    }
    
    clearStatus() {
        elements.get("successSpan").textContent = "";
    }
    
    setStatus(message, success) {
        const span = elements.get("successSpan");
    
        debug(`status span: ${span}`);
        debug(`status message: "${message}"`);
    
        if (!span) {
            debug("ERROR: successSpan is null/undefined.");
            return;
        }
    
        span.textContent = message;
        span.dataset.success = String(success);
        
        debug(`status after: "${span.textContent}"`);
    }
    
    async createItem() {
        debug("1");
    
        try {
            debug("before itemForm.create");
    
            const item =
                await itemForm.create();
    
            debug("after itemForm.create");
    
            itemList.add(item);
    
            debug("after itemList.add");
    
            itemPreview.show(item);
    
            debug("after itemPreview.show");
    
            this.clearForm();
    
            debug("after clearForm");
    
            await this.exportAddon();
    
            debug("after exportAddon");
    
            this.setStatus(
                `Item "${item.identifier}" created successfully.`,
                true
            );
    
            debug("after setStatus");
    
        } catch (error) {
            console.error(
                "createItem error:",
                error
            );
    
            debug(
                `ERROR: ${
                    error instanceof Error
                        ? error.stack
                        : String(error)
                }`
            );
    
            try {
                this.setStatus(
                    error instanceof Error
                        ? error.message
                        : String(error),
                    false
                );
            } catch (statusError) {
                console.error(
                    "setStatus error:",
                    statusError
                );
    
                debug(
                    `STATUS ERROR: ${String(statusError)}`
                );
            }
        }
    }
    
    clearForm() {
        for (const input of elements.getGroup("clearOnCreation")) {
            input.value = "";
        }
    }
    
    async exportAddon() {
        const addonExporter = new AddonExporter(
            addon.getAddon()
        );
        
        
        const files = addonExporter.export();
        debug("5");
        
        const packager = new AddonPackager(
            addon.getAddon().name
        );
        
        await packager.createAndDownloadMcaddon(files);
    }
    
    downloadItem(item) {
        itemDownload.download(item);
    }
}

const controller = new CreateItemController();

const events = new ItemEvents(
    elements,
    controller
);

events.bind();