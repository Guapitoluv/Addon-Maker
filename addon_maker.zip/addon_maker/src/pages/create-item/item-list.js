export class ItemList {
    constructor(elements, onSelect) {
        this.elements = elements;
        this.onSelect = onSelect;
    }

    add(item) {
        const element =
            document.createElement(
                "div"
            );

        element.classList.add(
            "item-list-entry"
        );

        element.textContent =
            `${item.identifier} — ${item.displayName}`;

        element.addEventListener(
            "click",
            () => {
                this.onSelect(item);
            }
        );

        this.elements
            .get("itemList")
            .appendChild(element);
    }
}