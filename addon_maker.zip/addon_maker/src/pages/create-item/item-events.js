export class ItemEvents {
    constructor(elements, controller) {
        this.elements = elements;
        this.controller = controller;
    }

    bind() {
        this.bindInfoButtons();
        this.bindInputs();
        this.bindCreateButton();
    }

    bindInfoButtons() {
        const buttons =
            document.querySelectorAll(
                ".info-button"
            );

        for (const button of buttons) {
            button.addEventListener(
                "click",
                event => {
                    event.stopPropagation();
                    
                    const field =
                        button.dataset.info;

                    const group =
                        button.dataset.infoGroup;
                    
                    this.controller
                        .showInfo(
                            field,
                            group
                        );
                }
            );
        }
    }

    bindInputs() {
        for (
            const input of
            this.elements.getGroup(
                "itemInputs"
            )
        ) {
            input.addEventListener(
                "input",
                () => {
                    this.controller
                        .clearStatus();
                }
            );
        }
    }

    bindCreateButton() {
        this.elements
            .get(
                "itemCreationConfirmBtn"
            )
            .addEventListener(
                "click",
                () => {
                    this.controller
                        .createItem();
                }
            );
    }
}