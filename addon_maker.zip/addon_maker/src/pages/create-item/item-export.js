export class ItemDownload {
    constructor(exporter) {
        this.exporter = exporter;
    }

    download(item) {
        const json =
            this.exporter.stringify(
                item
            );

        const blob =
            new Blob(
                [json],
                {
                    type:
                        "application/json"
                }
            );

        const url =
            URL.createObjectURL(
                blob
            );

        const anchor =
            document.createElement(
                "a"
            );

        const filename =
            `${item.identifier.replace(
                ":",
                "_"
            )}.json`;

        anchor.href = url;
        anchor.download = filename;

        anchor.click();

        URL.revokeObjectURL(url);
    }
}