export class ItemPreview {
    constructor(elements, exporter) {
        this.elements = elements;
        this.exporter = exporter;
    }

    show(item) {
        this.elements
            .get("output")
            .textContent =
                this.exporter.stringify(
                    item
                );
    }
}