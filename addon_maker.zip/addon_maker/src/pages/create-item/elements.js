class ElementIDNotFoundError extends Error {
    constructor(id) {
        super(`Element with id '${id}' not found.`);
        
        this.name = this.constructor.name;
        this.id = id;
    }
}

class GroupAlreadyExistsError extends Error {
    constructor(group) {
        super(`Group '${group}' already exists.`);
        
        this.name = this.constructor.name;
        this.group = group;
    }
}

class ElementlreadyExistsError extends Error {
    constructor(element) {
        super(`Element '${element}' already exists.`);
        
        this.name = this.constructor.name;
        this.element = element;
    }
}

class UnknownGroupError extends Error {
    constructor(group) {
        super(`Unknown group '${group}'`);
        
        this.name = this.constructor.name;
        this.group = group;
    }
}

class UnknownElementError extends Error {
    constructor(element) {
        super(`Unknown element '${element}'`);
        
        this.name = this.constructor.name;
        this.element = element;
    }
}

export class DOMElements {
    constructor(elements = {}) {
        this.elements = new Map();
        this.groups = new Map();

        for (const [tag, id] of Object.entries(elements)) {
            this.add(tag, id);
        }
    }

    add(tag, id) {
        if (this.elements.has(tag)) {
            throw new ElementAlreadyExistsError(tag);
        }

        const element =
            document.getElementById(id);

        if (!element) {
            throw new ElementIDNotFoundError(id);
        }

        this.elements.set(
            tag,
            element
        );

        return this;
    }

    get(tag) {
        const element =
            this.elements.get(tag);

        if (!element) {
            throw new UnknownElementError(tag);
        }

        return element;
    }

    has(tag) {
        return this.elements.has(tag);
    }

    remove(tag) {
        return this.elements.delete(tag);
    }

    addGroup(group) {
        if (this.groups.has(group)) {
            throw new GroupAlreadyExistsError(group);
        }

        this.groups.set(
            group,
            new Set()
        );

        return this;
    }

    group(group, tags) {
        if (this.groups.has(group)) {
            throw new GroupAlreadyExistsError(group);
        }

        const elements =
            new Set();

        for (const tag of tags) {
            if (!this.has(tag)) {
                throw new UnknownElementError(tag);
            }

            elements.add(tag);
        }

        this.groups.set(
            group,
            elements
        );

        return this;
    }

    getGroup(group) {
        return [
            ...this.getGroupTags(group)
        ].map(
            tag => this.get(tag)
        );
    }

    hasGroup(group) {
        return this.groups.has(group);
    }

    addToGroup(group, tag) {
        if (!this.hasGroup(group)) {
            this.addGroup(group);
        }

        if (!this.has(tag)) {
            throw new UnknownElementError(tag);
        }

        this.groups
            .get(group)
            .add(tag);

        return this;
    }

    removeFromGroup(group, tag) {
        const elements =
            this.groups.get(group);

        if (!elements) {
            throw new UnknownGroupError(group)
        }

        return elements.delete(tag);
    }

    removeGroup(group) {
        return this.groups.delete(group);
    }

    clearGroup(group) {
        const elements =
            this.groups.get(group);

        if (!elements) {
            throw new UnknownGroupError(group)
        }

        elements.clear();

        return this;
    }
    
    getGroupTags(group) {
        const tags =
            this.groups.get(group);

        if (!tags) {
            throw new UnknownGroupError(group)
        }
        
        return tags;
    }
    
    cloneGroup(newGroup, existingGroup) {
        this.group(
            newGroup,
            this.getGroupTags(existingGroup)
        );
    }
}