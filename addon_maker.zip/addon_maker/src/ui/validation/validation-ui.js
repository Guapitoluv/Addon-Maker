export class ValidationUI {

    constructor() {
        this.statusIcons = {
            success: "✓",
            warning: "⚠",
            error: "✕"
        };
    }


    update(result) {
        for (
            const [field, state]
            of Object.entries(result.fields)
        ) {
            this.updateField(field, state);
        }
    }


    updateField(field, state) {
        const elements =
            document.querySelectorAll(
                `[data-validation="${field}"]`
            );

        for (const element of elements) {
            element.classList.remove(
                "validation-success",
                "validation-warning",
                "validation-error"
            );

            const oldIndicator =
                element.querySelector(
                    ".validation-indicator"
                );

            oldIndicator?.remove();

            if (state.status === "success") {
                element.classList.add(
                    "validation-success"
                );

                this.addIndicator(
                    element,
                    "success",
                    state.message
                );
            }

            else if (state.status === "error") {
                element.classList.add(
                    "validation-error"
                );

                this.addIndicator(
                    element,
                    "error",
                    state.message
                );
            }

            else if (state.status === "optional") {
                element.classList.add(
                    "validation-warning"
                );

                this.addIndicator(
                    element,
                    "warning",
                    "Optional"
                );
            }
        }
    }


    addIndicator(element, status, message) {
        const indicator =
            document.createElement("span");

        indicator.className =
            "validation-indicator";

        indicator.dataset.status = status;

        indicator.textContent =
            this.statusIcons[status];

        if (message)
            indicator.title = message;

        element.appendChild(indicator);
    }
}