import {
    ITEM_FIELD_INFO,
    ITEM_GROUP_INFO
} from "../../docs/item-fields.js";


export class InfoPopover {

    constructor() {
        this.element = null;

        this.handleDocumentClick =
            this.handleDocumentClick.bind(this);

        document.addEventListener(
            "click",
            this.handleDocumentClick
        );
    }


    show(info) {

        this.close();

        this.element =
            document.createElement("div");

        this.element.className =
            "info-popover";

        this.element.innerHTML = `
            <div class="info-popover-header">

                <strong>
                    ${this.escapeHTML(info.title)}
                </strong>

                <button
                    type="button"
                    class="info-popover-close"
                    aria-label="Close information">
                    ×
                </button>

            </div>

            <div class="info-popover-description">
                ${this.escapeHTML(info.description)}
            </div>

            ${
                info.example !== undefined
                    ? `
                        <div class="info-popover-example">

                            <span>
                                Example
                            </span>

                            <code>
                                ${this.escapeHTML(
                                    String(info.example)
                                )}
                            </code>

                        </div>
                    `
                    : ""
            }
        `;

        document.body.appendChild(
            this.element
        );


        const closeButton =
            this.element.querySelector(
                ".info-popover-close"
            );


        closeButton.addEventListener(
            "click",
            event => {

                event.stopPropagation();

                this.close();
            }
        );
    }


    showField(fieldName) {

        const info =
            ITEM_FIELD_INFO[fieldName];


        if (!info) {
            throw new Error(
                `Unknown item field "${fieldName}".`
            );
        }


        this.show(info);
    }


    showGroup(groupName) {

        const info =
            ITEM_GROUP_INFO[groupName];


        if (!info) {
            throw new Error(
                `Unknown item group "${groupName}".`
            );
        }


        this.show(info);
    }


    close() {

        if (!this.element)
            return;


        this.element.remove();

        this.element = null;
    }


    handleDocumentClick(event) {

        if (!this.element)
            return;


        const target =
            event.target;


        if (!(target instanceof Element))
            return;


        /*
         * Clicking an information button should
         * not immediately close the popover.
         */
        if (
            target.closest(".info-button")
        ) {
            return;
        }


        /*
         * Clicking inside the popover should
         * not close it.
         */
        if (
            target.closest(".info-popover")
        ) {
            return;
        }


        /*
         * Any other click closes it.
         */
        this.close();
    }


    escapeHTML(value) {

        return String(value)
            .replaceAll(
                "&",
                "&amp;"
            )
            .replaceAll(
                "<",
                "&lt;"
            )
            .replaceAll(
                ">",
                "&gt;"
            )
            .replaceAll(
                '"',
                "&quot;"
            )
            .replaceAll(
                "'",
                "&#039;"
            );
    }
}