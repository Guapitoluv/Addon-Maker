export class PackManifest {

    static createBehaviorPack({
        name,
        description,
        uuid,
        moduleUuid,
        version = [1, 0, 0],
        minEngineVersion = [1, 21, 0],
        dependencies = []
    }) {
        const manifest = {
            format_version: 2,

            header: {
                name,
                description,
                uuid,
                version,
                min_engine_version: minEngineVersion
            },

            modules: [
                {
                    description,
                    type: "data",
                    uuid: moduleUuid,
                    version
                }
            ]
        };

        if (dependencies.length > 0) {
            manifest.dependencies = dependencies;
        }

        return manifest;
    }


    static createResourcePack({
        name,
        description,
        uuid,
        moduleUuid,
        version = [1, 0, 0],
        minEngineVersion = [1, 21, 0]
    }) {
        return {
            format_version: 2,

            header: {
                name,
                description,
                uuid,
                version,
                min_engine_version: minEngineVersion
            },

            modules: [
                {
                    description,
                    type: "resources",
                    uuid: moduleUuid,
                    version
                }
            ]
        };
    }


    static stringify(manifest) {
        return JSON.stringify(
            manifest,
            null,
            2
        );
    }
}