export class ItemExporter {

    static export(
        item,
        formatVersion = "1.21.0"
    ) {
        const description = {
            identifier:
                item.identifier
        };


        // =========================
        // CREATIVE MENU
        // =========================

        if (
            item.menuCategory !== null
        ) {
            description.menu_category = {
                category:
                    item.menuCategory
            };

            if (
                item.group !== null
            ) {
                description
                    .menu_category
                    .group =
                    item.group;
            }
        }


        if (
            item.hiddenInCommands
        ) {
            description
                .is_hidden_in_commands =
                true;
        }


        // =========================
        // COMPONENTS
        // =========================

        const components = {
            ...structuredClone(
                item.components
            )
        };


        // =========================
        // DISPLAY NAME
        // =========================

        if (
            item.displayName !== null
        ) {
            components[
                "minecraft:display_name"
            ] = {
                value:
                    item.displayName
            };
        }


        // =========================
        // ICON
        // =========================

        if (
            item.hasIcon()
        ) {
            components[
                "minecraft:icon"
            ] = item.identifier;
        }


        return {
            format_version:
                formatVersion,

            "minecraft:item": {
                description,
                components
            }
        };
    }


    static stringify(
        item,
        formatVersion = "1.21.0"
    ) {
        return JSON.stringify(
            this.export(
                item,
                formatVersion
            ),
            null,
            2
        );
    }
}