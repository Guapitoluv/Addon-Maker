import { ItemExporter } from "./item-exporter.js";
import { PackManifest } from "./pack-manifest.js";


export class AddonExporter {

    constructor(addon, options = {}) {
        this.addon = addon;

        this.options = {
            formatVersion:
                options.formatVersion ??
                "1.21.0",

            version:
                options.version ??
                [1, 0, 0],

            minEngineVersion:
                options.minEngineVersion ??
                [1, 21, 0],

            description:
                options.description ??
                `${addon.name} Add-On`
        };


        this.behaviorPackUuid =
            crypto.randomUUID();

        this.behaviorPackModuleUuid =
            crypto.randomUUID();

        this.resourcePackUuid =
            crypto.randomUUID();

        this.resourcePackModuleUuid =
            crypto.randomUUID();
    }


    // =========================
    // PUBLIC API
    // =========================

    export() {
        const files = new Map();

        this.exportBehaviorPack(files);
        this.exportResourcePack(files);

        return files;
    }


    // =========================
    // BEHAVIOR PACK
    // =========================

    exportBehaviorPack(files) {
        const manifest =
            PackManifest.createBehaviorPack({
                name: `${this.addon.name} BP`,
                description: this.options.description,
                uuid: this.behaviorPackUuid,
                moduleUuid: this.behaviorPackModuleUuid,
                version: this.options.version,
                minEngineVersion:
                    this.options.minEngineVersion,

                dependencies: [
                    {
                        uuid: this.resourcePackUuid,
                        version: this.options.version
                    }
                ]
            });


        files.set(
            "behavior_pack/manifest.json",

            PackManifest.stringify(
                manifest
            )
        );


        for (
            const item
            of this.addon.getItems()
        ) {
            this.exportItem(
                files,
                item
            );
        }
    }


    exportItem(files, item) {
        const itemJson =
            ItemExporter.stringify(
                item,
                this.options.formatVersion
            );


        const itemName =
            this.getItemName(item);


        files.set(
            `behavior_pack/items/${itemName}.json`,

            itemJson
        );
    }


    // =========================
    // RESOURCE PACK
    // =========================

    exportResourcePack(files) {
        const manifest =
            PackManifest.createResourcePack({
                name: `${this.addon.name} RP`,
                description: this.options.description,
                uuid: this.resourcePackUuid,
                moduleUuid: this.resourcePackModuleUuid,
                version: this.options.version,
                minEngineVersion:
                    this.options.minEngineVersion
            });


        files.set(
            "resource_pack/manifest.json",

            PackManifest.stringify(
                manifest
            )
        );


        this.exportItemTextures(
            files
        );

        this.exportItemModels(
            files
        );

        this.exportItemAttachables(
            files
        );
    }


    // =========================
    // TEXTURES
    // =========================

    exportItemTextures(files) {
        const textureData = {};


        for (
            const item
            of this.addon.getItems()
        ) {

            /*
             * ICON
             */

            if (item.hasIcon()) {
                const iconName =
                    this.getItemIconName(
                        item
                    );


                textureData[
                    item.identifier
                ] = {
                    textures:
                        `textures/items/${iconName}`
                };


                files.set(
                    `resource_pack/textures/items/${iconName}.png`,

                    item.getIcon()
                );
            }


            /*
             * MODEL TEXTURE
             */

            if (item.hasTexture()) {
                const textureName =
                    this.getItemTextureName(
                        item
                    );


                files.set(
                    `resource_pack/textures/items/${textureName}.png`,

                    item.getTexture()
                );
            }
        }


        if (
            Object.keys(textureData).length === 0
        ) {
            return;
        }


        const itemTexture = {
            resource_pack_name:
                `${this.addon.name} RP`,

            texture_data:
                textureData
        };


        files.set(
            "resource_pack/textures/item_texture.json",

            JSON.stringify(
                itemTexture,
                null,
                2
            )
        );
    }


    // =========================
    // MODELS
    // =========================

    exportItemModels(files) {
        for (
            const item
            of this.addon.getItems()
        ) {
            if (!item.hasModel()) {
                continue;
            }


            const model =
                item.getModel();


            const modelName =
                this.getItemModelName(
                    item
                );


            files.set(
                `resource_pack/models/entity/${modelName}.geo.json`,

                model.geometry
            );
        }
    }


    // =========================
    // ATTACHABLES
    // =========================

    exportItemAttachables(files) {
        for (
            const item
            of this.addon.getItems()
        ) {
            if (
                !item.hasModel() ||
                !item.hasTexture()
            ) {
                continue;
            }


            const attachable =
                this.createItemAttachable(
                    item
                );


            const modelName =
                this.getItemModelName(
                    item
                );


            files.set(
                `resource_pack/attachables/${modelName}.player.json`,

                JSON.stringify(
                    attachable,
                    null,
                    2
                )
            );
        }
    }


    createItemAttachable(item) {
        const model =
            item.getModel();


        return {
            format_version:
                "1.20.30",

            "minecraft:attachable": {
                description: {

                    identifier:
                        item.identifier,

                    item: {
                        [item.identifier]:
                            "query.is_owner_identifier_any('minecraft:player')"
                    },

                    materials: {
                        default:
                            "entity",

                        enchanted:
                            "entity_alphatest_glint"
                    },

                    textures: {
                        default:
                            `textures/items/${this.getItemTextureName(item)}`,

                        enchanted:
                            "textures/misc/enchanted_item_glint"
                    },

                    geometry: {
                        default:
                            model.geometryIdentifier
                    },

                    animations: {
                        hold_first_person:
                            "animation.steve_head.hold_first_person",

                        hold_third_person:
                            "animation.steve_head.hold_third_person"
                    },

                    scripts: {
                        animate: [
                            {
                                hold_first_person:
                                    "context.is_first_person == 1.0"
                            },
                            {
                                hold_third_person:
                                    "context.is_first_person == 0.0"
                            }
                        ]
                    },

                    render_controllers: [
                        "controller.render.item_default"
                    ]
                }
            }
        };
    }


    // =========================
    // NAMES
    // =========================

    getItemName(item) {
        const parts =
            item.identifier.split(":");

        return parts[1];
    }


    getItemIconName(item) {
        return `${this.getItemName(item)}_ico`;
    }


    getItemTextureName(item) {
        return this.getItemName(item);
    }


    getItemModelName(item) {
        return this.getItemName(item);
    }
}